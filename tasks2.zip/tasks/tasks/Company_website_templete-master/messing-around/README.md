# Messing around 

A Pen created on CodePen.io. Original URL: [https://codepen.io/mr-leon/pen/aZLLrw](https://codepen.io/mr-leon/pen/aZLLrw).

Proof of concept based on if we can introduce Redux into our site which already includes jQuery and Lodash. Introducing React and Webpack may be too much to incorporate at this time.